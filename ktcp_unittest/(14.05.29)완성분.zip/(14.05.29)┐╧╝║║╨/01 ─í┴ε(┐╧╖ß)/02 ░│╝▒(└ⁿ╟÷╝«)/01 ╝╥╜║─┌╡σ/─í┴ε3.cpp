#include <stdio.h>

int a1[101][101];
int n, m;

void fill3(int x, int y)
{
    if(x<1 || y<1 || x>n || y>m) return;
    if(a1[x][y]==3 || a1[x][y]==0)
    {
        a1[x][y]=2;
        fill3(x+1,y);
        fill3(x-1,y);
        fill3(x,y+1);
        fill3(x,y-1);
    }
}

int check(int x, int y)
{
    int t=0;
    if(a1[x+1][y]==2) t++;
    if(a1[x-1][y]==2) t++;
    if(a1[x][y+1]==2) t++;
    if(a1[x][y-1]==2) t++;
    return t;
}

int main()
{
    int i, j, hour=0, count;

    scanf("%d %d",&n, &m);

    for(i=1; i<=n; i++)
        for(j=1; j<=m; j++)
            scanf("%d",&a1[i][j]);
        
	fill3(1,1);
	        
    while(1)
    {
        count=0;
        for(i=1; i<=n; i++)
            for(j=1; j<=m; j++){
                if(a1[i][j]==1 && check(i,j)>=2){
                    a1[i][j]=3;
                    count++;
                }
            }

        if(count==0){
            printf("%d", hour);
            break;
        }
        
        for(i=1; i<=n; i++)
        	for(j=1; j<=m; j++)
        		if(a1[i][j]==3) fill3(i,j);
       hour++;
    }
    return 0;
}
