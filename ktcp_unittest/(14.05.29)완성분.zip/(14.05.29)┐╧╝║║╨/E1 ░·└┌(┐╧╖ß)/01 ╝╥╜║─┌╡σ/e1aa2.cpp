#include <stdio.h>

int main()
{
  int k, n, m, get;
	
	scanf("%d %d %d", &k, &n, &m);
	
  get = n*k - m;

  printf("%d\n", get>0 ? get:0);
	
  return 0;
}
