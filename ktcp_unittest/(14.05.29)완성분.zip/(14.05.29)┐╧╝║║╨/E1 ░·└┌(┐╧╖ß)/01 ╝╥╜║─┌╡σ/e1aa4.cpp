#include <stdio.h>

long long int f(long long int x, long long int y)
{
	return x>y ? x:y;
}

int main()
{
  long long int k, n, m, get;
	
  scanf("%lld %lld %lld", &k, &n, &m);
	
  get = n*k - m;

  printf("%lld\n", f(get,0));
	
  return 0;
}
