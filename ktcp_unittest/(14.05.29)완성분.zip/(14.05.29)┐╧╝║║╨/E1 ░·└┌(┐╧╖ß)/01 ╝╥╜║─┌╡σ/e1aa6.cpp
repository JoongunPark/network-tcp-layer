#include <stdio.h>

long long int k, n, m, get;

void input()
{
  scanf("%lld %lld %lld", &k, &n, &m);
}

void process()
{
  get = n*k - m;
}

long long int max(long long int x, long long int y)
{
	return x>y ? x:y;
}

void output()
{
  printf("%lld\n", max(get,0));
}

int main()
{
  input();
	process();
	output();	
  return 0;
}
