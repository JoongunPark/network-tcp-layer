#include <stdio.h>

int main()
{
	int k, n, m, get;
	
	scanf("%d %d %d", &k, &n, &m);
	
	get = n*k - m;
	
	if(get < 0) printf("0\n");
	else printf("%d\n", get);
	
	return 0;
}
