#include<cstdio>
int main()
{
  int k,n,m;
  scanf("%d%d%d",&n,&k,&m);
  printf("%d",n*k-m>0?n*k-m:0);
}
