#include <stdio.h>

int f(int x, int y)
{
	return x>y ? x:y;
}

int main()
{
  int k, n, m, get;
	
	scanf("%d %d %d", &k, &n, &m);
	
  get = n*k - m;

  printf("%d\n", f(get,0));
	
  return 0;
}
