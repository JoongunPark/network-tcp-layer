#include <stdio.h>
int COW[80000];
int main()
{
    int n;
    long long int ans = 0;
    scanf("%d", &n);
    for(int i = 0 ; i < n ; i++ )
        scanf("%d", &COW[i]);
    for(int i = 1 ; i < n ; i++ )
    {
        int cow = COW[i];
        for(int j = i-1 ; j >= 0 ; j-- )
            if( cow < COW[j] )
                ans++, cow = COW[j];
    }
    printf("%lld\n",ans);
}
