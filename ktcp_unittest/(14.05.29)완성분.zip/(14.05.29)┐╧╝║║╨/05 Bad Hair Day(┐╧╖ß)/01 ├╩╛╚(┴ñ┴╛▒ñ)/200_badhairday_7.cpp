#include <stdio.h>
#include <stack>
using namespace std;
stack<int> S;
long long int ans;
int main()
{
    int n, COW;
    scanf("%d", &n);
    for(int i = 0 ; i < n ; i++ )
    {
        scanf("%d", &COW);
        while(!S.empty() && S.top() <= COW ) S.pop();
        ans+=S.size();
        S.push(COW);
    }
    printf("%lld\n", ans);
}
