#include <stdio.h>
int COW[80000];
int main()
{
    int n;
    long long int ans = 0;
    scanf("%d", &n);
    for(int i = 0 ; i < n ; i++ )
        scanf("%d", &COW[i]);
    for(int i = 0 ; i < n-1 ; i++ )
        for(int j = i+1 ; j < n && COW[i] > COW[j] ; j++ )
            if( COW[i] > COW[j] )
                ans++;
            else
                break;
    printf("%lld\n",ans);
}
