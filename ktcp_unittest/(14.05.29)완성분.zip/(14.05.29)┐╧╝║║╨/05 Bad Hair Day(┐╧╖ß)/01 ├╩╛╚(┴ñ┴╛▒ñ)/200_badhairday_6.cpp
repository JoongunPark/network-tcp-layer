#include <stdio.h>
#include <algorithm>
using namespace std;

int COW, SOLVE[80000], n, ins;
long long int ans;
bool cmp(const int a, const int b){ return a>b; }
int main()
{
    int i , j;
    scanf("%d", &n);
    for(i = 0 ; i < n ; i++ )
    {
        scanf("%d", &COW);
        ins = (int)(lower_bound(SOLVE, SOLVE+ins+1, COW, cmp) - SOLVE);
        ans += ins;
        SOLVE[ins] = COW;
    }
    printf("%lld\n", ans);
}
