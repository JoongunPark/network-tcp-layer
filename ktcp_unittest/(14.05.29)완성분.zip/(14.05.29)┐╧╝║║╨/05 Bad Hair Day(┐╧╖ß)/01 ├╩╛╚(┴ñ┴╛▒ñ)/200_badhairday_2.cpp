#include <stdio.h>
struct SEGMENT_TREE{
    long long int height, index;
} COW[1<<18];
int base;
long long int max(int a, int b)
{
    SEGMENT_TREE m=COW[b];
    while(a<b)
    {
        if(a%2==1)
        {
            if( m.height < COW[a].height ) m = COW[a];
            else if( ( m.height == COW[a].height ) && (m.index < COW[a].index) ) m = COW[a];
            a++;
        }
        if(b%2==0)
        {
            if( m.height < COW[b].height ) m = COW[b];
            else if((m.height == COW[b].height) && (m.index < COW[b].index) ) m = COW[b];
            b--;
        }
        a>>=1, b>>=1;
    }
    if( a == b )
        if( m.height < COW[b].height ) m = COW[b];
        else if((m.height == COW[b].height) && (m.index < COW[b].index) ) m = COW[b];
    return m.index;
}
long long int Solve(int a, int b)
{
    if( a >= b ) return 0;
    long long int m = max(a, b);
    return Solve(a,m-1)+Solve(m+1,b)+(b-m);
}
int main()
{
    int n;
    scanf("%d", &n);
    for(base = 1 ; base < n ; base<<=1);
    for(int i = base ; i < n+base ; i++ )
        scanf("%lld", &COW[i].height), COW[i].index = i;
    for(int i = base-1 ; i >= 0 ; i-- )
        COW[i] = (COW[2*i].height <= COW[2*i+1].height ? COW[2*i+1] : COW[2*i]);
    printf("%lld\n",Solve(base,base+n-1));
}
