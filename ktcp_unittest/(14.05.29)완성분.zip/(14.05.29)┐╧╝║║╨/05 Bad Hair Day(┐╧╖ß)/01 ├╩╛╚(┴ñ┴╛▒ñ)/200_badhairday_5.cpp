#include <stdio.h>

int COW, SOLVE[80000], n, ins;
long long int ans;
int main()
{
    int i , j;
    scanf("%d", &n);
    for(i = 0 ; i < n ; i++ )
    {
        scanf("%d", &COW);
        for(j = 0 ; j <= ins ; j++ )
            if( COW >= SOLVE[j] )
                break;
        ans += ins = j;
        SOLVE[ins] = COW;
    }
    printf("%lld\n", ans);
}
