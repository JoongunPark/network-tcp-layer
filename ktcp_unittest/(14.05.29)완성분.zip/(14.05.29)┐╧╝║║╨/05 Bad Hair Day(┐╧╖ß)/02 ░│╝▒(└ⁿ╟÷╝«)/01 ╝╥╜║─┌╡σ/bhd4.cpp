#include <stdio.h>
int h[80001];
int main()
{
  int n, i, j, m;
  long long int t=0;
  scanf("%d", &n);
  for(i=1; i<=n; i++)
    scanf("%d", &h[i]);
	
  for(i=1; i<=n; i++){
  	m=h[i];
    for(j=i-1; j>=1; j--)
      if(h[j] > m){
        t++;
        m=h[j];
      }
	}
  printf("%lld\n", t);
  return 0;
}
