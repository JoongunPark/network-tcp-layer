#include <stdio.h>
int h[80001];
int max(int a, int b)
{
  int i, m=a;
  for(i=a+1; i<=b; i++)
    if(h[i]>=h[m]) m=i;
  return m;
}

long long int hair(int a, int b)
{
  int m;
  if(a >= b) return 0;
  m = max(a, b);
  return hair(a,m-1)+hair(m+1,b)+(b-m);
}

int main()
{
  int n, i, j;
  long long int t=0;
  
  scanf("%d", &n);
  for(i=1; i<=n; i++)
    scanf("%d", &h[i]);
		
  printf("%lld\n", hair(1,n));

  return 0;
}
