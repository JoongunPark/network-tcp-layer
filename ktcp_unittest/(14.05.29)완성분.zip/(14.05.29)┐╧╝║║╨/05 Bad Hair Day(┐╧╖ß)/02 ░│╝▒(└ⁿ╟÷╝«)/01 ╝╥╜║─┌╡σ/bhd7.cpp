#include <stdio.h>
#include <stack>
using namespace std;
stack<int> S;
int main()
{
  int n, cow, i;
  long long int t=0;
  scanf("%d", &n);
  for(i=1; i<=n; i++)
  {
    scanf("%d", &cow);
    while(!S.empty() && S.top() <= cow) S.pop();
    t += S.size();
    S.push(cow);
  }
  printf("%lld\n", t);
  return 0;
}
