#include <stdio.h>

int h[80001];

int main()
{
  int n, i, j;
  long long int t=0;
  
  scanf("%d", &n);
  for(i=1; i<=n; i++)
    scanf("%d", &h[i]);
	
  for(i=1; i<=n; i++)
    for(j=i+1; j<=n; j++)
      if(h[i] > h[j]) t++;
      else break;
	
  printf("%lld\n", t);
  return 0;
}
