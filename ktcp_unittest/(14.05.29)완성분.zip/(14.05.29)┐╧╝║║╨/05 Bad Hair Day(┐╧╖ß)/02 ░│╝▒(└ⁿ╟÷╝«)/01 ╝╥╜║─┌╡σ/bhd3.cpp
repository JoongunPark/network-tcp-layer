#include <stdio.h>
struct TREE{
  long long int h, i;
} cow[1<<18];

int base;

long long int max(int a, int b)
{
  TREE m = cow[b];
  while(a<b)
  {
    if(a%2==1){
    	if(m.h<cow[a].h || (m.h==cow[a].h && m.i<cow[a].i))
			  m=cow[a];
		  a++;
    }
    if(b%2==0){
    	if(m.h<cow[b].h || (m.h==cow[b].h && m.i<cow[b].i))
    	  m=cow[b];
    	b--;
    }
    a>>=1, b>>=1;
  }
  if(a==b)
    if(m.h<cow[b].h || (m.h==cow[b].h && m.i<cow[b].i))
      m=cow[b];
  return m.i;
}

long long int hair(int a, int b)
{
  long long int m;
  if(a >= b) return 0;
  m = max(a, b);
  return hair(a,m-1)+hair(m+1,b)+(b-m);
}

int main()
{
  int n, i, j;
  long long int t=0;
  
  scanf("%d", &n);
  for(base=1; base<n; base<<=1);
  for(i=base; i<n+base; i++)
  {
    scanf("%d", &cow[i].h);
    cow[i].i=i;
	}
	for(i=base-1; i>=0; i--)
	  cow[i]=(cow[2*i].h <= cow[2*i+1].h ? cow[2*i+1]:cow[2*i]);
	  
  printf("%lld\n", hair(base,base+n-1));

  return 0;
}
