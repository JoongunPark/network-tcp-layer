#include <stdio.h>
#include <algorithm>
using namespace std;

int insert[80001];

bool cmp(int a, int b){return a>b;}

int main()
{
  int n, cow, i, j, last=0;
  long long int t=0;
  scanf("%d", &n);
  for(i=1; i<=n; i++)
  {
    scanf("%d", &cow);
    last = (int)(lower_bound(insert, insert+last+1, cow, cmp)-insert);
    t += last;
    insert[last]=cow;
  }
  printf("%lld\n", t);
  return 0;
}
