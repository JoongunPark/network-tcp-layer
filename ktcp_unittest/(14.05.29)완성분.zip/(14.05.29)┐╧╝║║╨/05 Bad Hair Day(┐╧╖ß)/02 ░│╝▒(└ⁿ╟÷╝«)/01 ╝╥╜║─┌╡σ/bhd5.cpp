#include <stdio.h>
int insert[80001];
int main()
{
  int n, cow, i, j, last=0;
  long long int t=0;
  scanf("%d", &n);
  for(i=1; i<=n; i++)
  {
    scanf("%d", &cow);
    for(j=0; j<=last; j++)
      if(cow >= insert[j]) break;
    last = j;
    t += last;
    insert[last]=cow;
  }
  printf("%lld\n", t);
  return 0;
}
