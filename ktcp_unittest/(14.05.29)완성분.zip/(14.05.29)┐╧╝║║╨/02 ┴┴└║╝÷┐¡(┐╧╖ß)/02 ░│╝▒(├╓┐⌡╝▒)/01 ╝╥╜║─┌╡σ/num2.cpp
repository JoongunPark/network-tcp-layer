#include <stdio.h>
int s[81];
int n, end=0;
bool same(int a, int b)
{
  int i;
  for(i=a; i<b; i++)
    if(s[i]!=s[i+b-a]) break;
  return (a==b ? false:i==b);
}

int good(int m)
{
  int i, j;
  for(i=m-1, j=m; i>0; i-=2,j-=1)
    if(same(i,j)) return 0;
  return 1;
}

void make(int k)
{
  if(k>n) end=1;
  if(end==0) {s[k]=1; if(good(k)) make(k+1);}
  if(end==0) {s[k]=2; if(good(k)) make(k+1);}
  if(end==0) {s[k]=3; if(good(k)) make(k+1);}
  if(end==0) s[k]=0;
}

int main()
{
  scanf("%d", &n);
  make(1);
  for(int i=1; i<=n; i++) printf("%d",s[i]);    
  return 0;
}
