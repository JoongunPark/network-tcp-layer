#include <stdio.h>
#include <algorithm>
struct w {int a; int b;} d[100001];
int L[100001];
bool cmp(w x, w y){return x.a < y.a;}
int f(int s, int e, int x)
{
	int mid;
	if(s>=e) return s;
	mid=(s+e)/2;
	if(x < L[mid]) f(s, mid, x);
  else if(L[mid] < x) f(mid+1, e, x);
}

int main()
{
	int i, j, n, m, t;
	scanf("%d", &n);
	
  for(i=1; i<=n; i++)
    scanf("%d %d", &d[i].a, &d[i].b);
  std::sort(d+1, d+n+1, cmp);

  m=0;
  for(i=1; i<=n; i++)
  {
  	t=f(1,m+1, d[i].b);
  	if(L[t]==0) m++;
  	L[t]=d[i].b;
  }
  
	printf("%d\n", n-m);
}
