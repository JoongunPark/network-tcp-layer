#include <stdio.h>
#include <algorithm>
using namespace std;
struct w {int a; int b;} d[100001];
int TR[1<<22];
bool cmp(w x, w y){return x.a < y.a;}
void up(int n)
{
  while(n>1)
  {
  	if(TR[n]>TR[n/2]) TR[n/2]=TR[n];
  	n>>=1;
  }
}
int get(int s, int e)
{
	int m=0;
	while(s<e)
	{
		m = max(m, TR[e]);
		if(!(e%2)) e--;
		e>>=1;
		s>>=1;
	}
	if(s>=e) return max(m, TR[s]);
}

int main()
{
	int i, base, n, m=-1;
	scanf("%d", &n);
	
  for(i=1; i<=n; i++)
  {
    scanf("%d %d", &d[i].a, &d[i].b);
    if(m < d[i].b) m=d[i].b;
  }
  sort(d+1, d+n+1, cmp);
  for(base=1; base<m; base<<=1); 
  for(i=1; i<=n; i++)
  {
    TR[base+d[i].b-1]=get(base, base+d[i].b-2)+1;
    up(base+d[i].b-1);
  }
  
	printf("%d\n", n-TR[1]);
}
