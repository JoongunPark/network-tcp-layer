#include <stdio.h>
#include <algorithm>
struct w {int a; int b;} d[100001];
int t[100001];
bool cmp(w x, w y){return x.a < y.a;}
int main()
{
	int i, j, n, m;
	scanf("%d", &n);
	
  for(i=1; i<=n; i++)
    scanf("%d %d", &d[i].a, &d[i].b);
  std::sort(d+1, d+n+1, cmp);

  for(i=1; i<=n; i++) t[i]=1;

	for(i=2; i<=n; i++)
		for(j=1; j<i; j++)
		  if(d[i].b>d[j].b && t[i]<t[j]+1)
			   t[i]=t[j]+1;
  m=1;
	for(i=1; i<=n; i++) if(m<t[i]) m=t[i];
	printf("%d\n", n-m);
}
