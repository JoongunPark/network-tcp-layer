#include <stdio.h>
char s[401];
int T[2][10]={
  2, 3, 9, 4, 4, 2, 2, 8, 4, 9,
  1, 9, 6, 9, 5, 7, 1, 7, 6, 9
};
int main()
{
  int i=0, j;
  scanf("%s", s);
  
  for(j=0; s[j]; j++)
    i=T[s[j]-'0'][i];

  puts((i==5 || i==6 || i==7) ? "SUBMARINE":"NOISE");

  return 0;
}

