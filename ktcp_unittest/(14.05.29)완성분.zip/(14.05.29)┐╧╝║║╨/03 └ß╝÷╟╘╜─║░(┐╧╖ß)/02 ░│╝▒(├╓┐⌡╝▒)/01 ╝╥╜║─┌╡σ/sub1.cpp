#include <stdio.h>
#include <string.h>
char s[401];
int main()
{
	int n, i=0, j;
  scanf("%s", s);
  n=strlen(s);
  while(i<n)
  {
    if(s[i]=='0'&&s[i+1]=='1') i+=2;
		else if(s[i]=='1'&&s[i+1]=='0'&&s[i+2]=='0')
		{
			for(j=i+3; s[j]=='0'; j++);  i=j;
			for(j=i; s[j]=='1'; j++);    i=j;
			if(s[i-2]=='1'&&s[i-1]=='1'&&s[i]=='0'&&s[i+1]=='0') i--;
		}
		else
		  break;
  }
 	if(i==n) printf("SUBMARINE\n");
	else printf("NOISE\n");
//  printf("%s", i==n ? "SUB\n":"Not SUB\n");
	return 0;
}
